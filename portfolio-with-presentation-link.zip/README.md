# Student Portfolio — starter

A responsive personal portfolio starter for showing your university and personal projects. It's plain HTML, CSS and JavaScript — no installs or build tools required.

## Quick start

1. Open `index.html` in your browser.
2. Edit the `portfolio` object at the TOP of `script.js`:
   - name, role, school, location
   - email / GitHub / LinkedIn (leave blank until ready)
   - your skills and about text
   - your **real projects**, replacing the 3 example cards
3. For each project, set:
   - `title`, `type` (`Web`, `Systems`, `Data`, or another category)
   - `category`, `description`, `technologies`
   - `github` and `demo` links (if available)
   - `placeholder: false` after adding real content
4. Adjust colors and layout in `styles.css` if you want a different look.

**Important:** The included projects and skills are placeholders, NOT verified student work. Remove or replace them before publishing. The code illustrations are decorative.

## Publish for free with GitHub Pages

1. Create a public GitHub repository named `<your-username>.github.io`.
2. Upload the contents of this folder (`index.html`, `styles.css`, `script.js`) to the repository root.
3. In repository **Settings → Pages**, choose **Deploy from a branch**, `main`, `/ (root)` and save.
4. Open `https://<your-username>.github.io/` after the site is deployed.

A custom domain is **optional**.

## Files

- `index.html`: page structure.
- `styles.css`: responsive visual design.
- `script.js`: all your content, project cards, category filtering, and links.

## Google Drive presentation added

The first project card links to the shared **Google Drive folder** supplied in the chat.
It says **Open Drive folder** rather than **View Presentation**, because it is not a direct PowerPoint file link.

To link directly to the PowerPoint:

1. In Google Drive, open the folder.
2. Right-click the PowerPoint itself → **Share** → **Copy link**.
3. Make sure *General access → Anyone with the link → Viewer* if you want portfolio visitors to see it.
4. In `script.js`, in the first project, replace `demo` with the copied file URL, and update `demoLabel` to `View presentation`.
5. Replace the temporary project `title`, `description`, `technologies` and set `placeholder: false` once you've filled in accurate details.

**Privacy:** Sharing a folder exposes every accessible file in it. For a public portfolio, prefer sharing only the PowerPoint file after reviewing its contents.
